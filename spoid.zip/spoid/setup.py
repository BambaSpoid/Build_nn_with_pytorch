from setuptools import setup

setup(name = 'spoid',
version='0.1',
description='helpers file',
packages=['data','src'],
zip_safe=False)